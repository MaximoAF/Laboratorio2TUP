package Trabajos_en_clase.Polimorfismo.Universal.Herencia;

public class Vehiculo {
    String material;
    void showMessage(){
        System.out.println("Llamando metodo de vehiculo");
    }
}
