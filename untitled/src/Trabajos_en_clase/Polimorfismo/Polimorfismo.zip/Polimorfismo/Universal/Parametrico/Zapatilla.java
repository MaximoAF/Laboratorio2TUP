package Trabajos_en_clase.Polimorfismo.Universal.Parametrico;

public class Zapatilla {
    private String modelo;

    public Zapatilla(String modelo) {
        this.modelo = modelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
