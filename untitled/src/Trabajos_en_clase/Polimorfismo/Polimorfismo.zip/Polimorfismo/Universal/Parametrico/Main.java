package Trabajos_en_clase.Polimorfismo.Universal.Parametrico;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Zapatilla> zapatillas = new ArrayList<>();
        ArrayList<Integer> numeros = new ArrayList<>();

        Zapatilla zapatilla1 = new Zapatilla("Campus00");
        zapatillas.add(zapatilla1);
        numeros.add(1);
    }
}
