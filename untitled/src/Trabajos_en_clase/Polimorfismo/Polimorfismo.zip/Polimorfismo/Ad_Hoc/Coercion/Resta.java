package Trabajos_en_clase.Polimorfismo.Ad_Hoc.Coercion;

public class Resta {
    public double restar(int a, int b){
        return a - b;
    }
}
