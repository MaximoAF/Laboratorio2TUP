package Trabajos_Practicos.TP_Exepciones.Parte_B;

public class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}