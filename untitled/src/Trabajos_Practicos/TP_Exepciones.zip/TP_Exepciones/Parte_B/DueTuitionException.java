package Trabajos_Practicos.TP_Exepciones.Parte_B;

public class DueTuitionException extends Exception {
    public DueTuitionException(String message) {
        super(message);
    }
}